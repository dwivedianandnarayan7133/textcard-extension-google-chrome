/**
 * content.js – TextCard Content Script
 * Injects a floating button on text selection and a Shadow-DOM modal
 * for postcard preview, theming, download, and clipboard copy.
 *
 * Architecture:
 *  - All UI lives inside Shadow DOM → zero style leakage
 *  - html2canvas renders the postcard div → PNG blob
 *  - chrome.storage.sync for user preferences
 */

(() => {
  'use strict';

  // ── Guard: run only once ─────────────────────────────────────────────────
  if (window.__textcardInjected) return;
  window.__textcardInjected = true;

  // ── Constants ────────────────────────────────────────────────────────────
  const THEMES = {
    dark: {
      label:      'Dark',
      background: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)',
      card:       'rgba(255,255,255,0.06)',
      border:     'rgba(255,255,255,0.12)',
      text:       '#f0f0f0',
      meta:       'rgba(200,200,255,0.55)',
      accent:     '#7c6ff7',
      shadow:     '0 24px 60px rgba(0,0,0,0.7)',
    },
    light: {
      label:      'Light',
      background: 'linear-gradient(135deg, #e8ecf0, #f5f7fa)',
      card:       'rgba(255,255,255,0.85)',
      border:     'rgba(0,0,0,0.08)',
      text:       '#1a1a2e',
      meta:       'rgba(60,60,100,0.55)',
      accent:     '#5b4ae8',
      shadow:     '0 24px 60px rgba(0,0,0,0.18)',
    },
    sunset: {
      label:      'Sunset',
      background: 'linear-gradient(135deg, #1a0533, #4a0e2e, #8b1a4a)',
      card:       'rgba(255,200,180,0.08)',
      border:     'rgba(255,150,120,0.25)',
      text:       '#ffe8d6',
      meta:       'rgba(255,200,180,0.55)',
      accent:     '#ff7043',
      shadow:     '0 24px 60px rgba(80,0,20,0.6)',
    },
    ocean: {
      label:      'Ocean',
      background: 'linear-gradient(135deg, #0a192f, #0d3b6e, #1565c0)',
      card:       'rgba(100,180,255,0.07)',
      border:     'rgba(100,200,255,0.2)',
      text:       '#e0f4ff',
      meta:       'rgba(150,210,255,0.55)',
      accent:     '#29b6f6',
      shadow:     '0 24px 60px rgba(0,20,60,0.7)',
    },
    forest: {
      label:      'Forest',
      background: 'linear-gradient(135deg, #0a1f0a, #1b4332, #2d6a4f)',
      card:       'rgba(100,200,130,0.07)',
      border:     'rgba(100,220,150,0.2)',
      text:       '#d8f3dc',
      meta:       'rgba(150,220,170,0.55)',
      accent:     '#52b788',
      shadow:     '0 24px 60px rgba(0,20,10,0.7)',
    },
  };

  const DEFAULT_PREFS = {
    theme:        'dark',
    brandingName: 'TextCard',
  };

  // ── State ────────────────────────────────────────────────────────────────
  let prefs           = { ...DEFAULT_PREFS };
  let floatBtn        = null;
  let modalHost       = null;  // Shadow host element
  let lastSelection   = '';
  let lastRange       = null;
  let isGenerating    = false;
  let selectionTimer  = null;
  let btnHideTimer    = null;

  // ── Load Preferences ─────────────────────────────────────────────────────
  function loadPrefs() {
    try {
      chrome.storage.sync.get(DEFAULT_PREFS, (result) => {
        prefs = { ...DEFAULT_PREFS, ...result };
      });
    } catch (e) {
      // Silently use defaults if storage unavailable
    }
  }
  loadPrefs();

  // ── Helpers ──────────────────────────────────────────────────────────────
  function getDomain() {
    try {
      return location.hostname.replace(/^www\./, '');
    } catch {
      return location.hostname || 'unknown';
    }
  }

  function formatDate(d = new Date()) {
    const months = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'];
    const pad  = (n) => String(n).padStart(2, '0');
    const day  = d.getDate();
    const mon  = months[d.getMonth()];
    const yr   = d.getFullYear();
    let   hr   = d.getHours();
    const min  = pad(d.getMinutes());
    const ampm = hr >= 12 ? 'PM' : 'AM';
    hr = hr % 12 || 12;
    return `${day} ${mon} ${yr} • ${hr}:${min} ${ampm}`;
  }

  function truncate(str, max = 600) {
    if (str.length <= max) return str;
    return str.slice(0, max).trimEnd() + '…';
  }

  function escapeHTML(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── Floating Button ──────────────────────────────────────────────────────
  function createFloatBtn() {
    if (floatBtn) return;

    floatBtn = document.createElement('div');
    floatBtn.id = '__textcard-float-btn';
    floatBtn.setAttribute('role', 'button');
    floatBtn.setAttribute('aria-label', 'Generate Postcard');
    floatBtn.tabIndex = 0;

    Object.assign(floatBtn.style, {
      position:       'fixed',
      zIndex:         '2147483647',
      display:        'none',
      alignItems:     'center',
      gap:            '6px',
      padding:        '7px 14px 7px 10px',
      background:     'linear-gradient(135deg, #302b63, #24243e)',
      color:          '#fff',
      fontSize:       '13px',
      fontFamily:     "'Segoe UI', system-ui, -apple-system, sans-serif",
      fontWeight:     '600',
      borderRadius:   '24px',
      boxShadow:      '0 4px 20px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.12)',
      cursor:         'pointer',
      userSelect:     'none',
      transition:     'transform 0.15s ease, box-shadow 0.15s ease, opacity 0.15s ease',
      letterSpacing:  '0.01em',
      whiteSpace:     'nowrap',
      pointerEvents:  'auto',
      backdropFilter: 'blur(8px)',
      WebkitBackdropFilter: 'blur(8px)',
    });

    floatBtn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" style="flex-shrink:0" aria-hidden="true">
        <rect x="2" y="3" width="20" height="18" rx="3" stroke="#a78bfa" stroke-width="2"/>
        <line x1="7" y1="9" x2="17" y2="9" stroke="#a78bfa" stroke-width="2" stroke-linecap="round"/>
        <line x1="7" y1="13" x2="14" y2="13" stroke="#a78bfa" stroke-width="2" stroke-linecap="round"/>
        <line x1="7" y1="17" x2="11" y2="17" stroke="#a78bfa" stroke-width="2" stroke-linecap="round"/>
      </svg>
      Generate Postcard
    `;

    // Hover effects
    floatBtn.addEventListener('mouseenter', () => {
      floatBtn.style.transform  = 'translateY(-2px) scale(1.03)';
      floatBtn.style.boxShadow  = '0 8px 28px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.18)';
    });
    floatBtn.addEventListener('mouseleave', () => {
      floatBtn.style.transform  = 'translateY(0) scale(1)';
      floatBtn.style.boxShadow  = '0 4px 20px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.12)';
    });

    floatBtn.addEventListener('mousedown', (e) => e.preventDefault()); // Preserve selection
    floatBtn.addEventListener('click', handleFloatClick);
    floatBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleFloatClick(); }
    });

    document.documentElement.appendChild(floatBtn);
  }

  function showFloatBtn(x, y) {
    createFloatBtn();
    clearTimeout(btnHideTimer);

    const margin = 10;
    const btnW   = 180;
    const btnH   = 36;
    let   left   = Math.min(x + 10, window.innerWidth  - btnW - margin);
    let   top    = Math.max(y - btnH - 10, margin + scrollY);

    // Prefer below if insufficient space above
    if (top < scrollY + margin) top = y + 14 + scrollY;

    floatBtn.style.left    = `${Math.max(margin, left)}px`;
    floatBtn.style.top     = `${top}px`;
    floatBtn.style.display = 'flex';
    floatBtn.style.opacity = '0';

    requestAnimationFrame(() => {
      floatBtn.style.transition = 'opacity 0.2s ease, transform 0.2s ease, box-shadow 0.15s ease';
      floatBtn.style.opacity    = '1';
      floatBtn.style.transform  = 'translateY(0) scale(1)';
    });
  }

  function hideFloatBtn(delay = 0) {
    clearTimeout(btnHideTimer);
    if (!floatBtn) return;
    btnHideTimer = setTimeout(() => {
      if (floatBtn) floatBtn.style.display = 'none';
    }, delay);
  }

  // ── Text Selection Detection ──────────────────────────────────────────────
  function getSelectedText() {
    try {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return { text: '', range: null };
      const text = sel.toString().trim();
      if (!text) return { text: '', range: null };
      return { text, range: sel.getRangeAt(0).cloneRange() };
    } catch {
      return { text: '', range: null };
    }
  }

  function getSelectionCoords(range) {
    try {
      const rect = range.getBoundingClientRect();
      return {
        x: rect.right  + window.scrollX,
        y: rect.bottom + window.scrollY,
      };
    } catch {
      return { x: 100, y: 100 };
    }
  }

  document.addEventListener('mouseup', (e) => {
    // Don't process clicks inside our own UI
    if (isInsideOurUI(e.target)) return;

    clearTimeout(selectionTimer);
    selectionTimer = setTimeout(() => {
      const { text, range } = getSelectedText();
      if (text.length >= 3) {
        lastSelection = text;
        lastRange     = range;
        const coords  = getSelectionCoords(range);
        showFloatBtn(coords.x, coords.y);
      } else {
        hideFloatBtn();
      }
    }, 100);
  });

  document.addEventListener('mousedown', (e) => {
    if (isInsideOurUI(e.target)) return;
    hideFloatBtn(300);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      hideFloatBtn();
      closeModal();
    }
  });

  function isInsideOurUI(el) {
    if (!el) return false;
    if (floatBtn && floatBtn.contains(el)) return true;
    if (modalHost && modalHost.contains(el)) return true;
    return false;
  }

  // ── Float Button Click Handler ────────────────────────────────────────────
  function handleFloatClick() {
    hideFloatBtn();
    if (!lastSelection) return;
    openModal(lastSelection);
  }

  // ── Message Listener (from background) ───────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'OPEN_POSTCARD_FROM_CONTEXT') {
      lastSelection = msg.text;
      openModal(msg.text);
    }
    if (msg.action === 'TRIGGER_FROM_SHORTCUT') {
      const { text } = getSelectedText();
      if (text.length >= 3) {
        lastSelection = text;
        hideFloatBtn();
        openModal(text);
      }
    }
  });

  // ── Shadow DOM Modal ──────────────────────────────────────────────────────
  function openModal(text) {
    closeModal(); // remove any existing

    loadPrefs(); // refresh prefs

    const host = document.createElement('div');
    host.id = '__textcard-modal-host';
    Object.assign(host.style, {
      position:     'fixed',
      inset:        '0',
      zIndex:       '2147483646',
      pointerEvents: 'auto',
    });

    const shadow = host.attachShadow({ mode: 'closed' });
    modalHost = host;
    document.documentElement.appendChild(host);

    const theme = THEMES[prefs.theme] || THEMES.dark;
    renderShadowContent(shadow, text, theme);
  }

  function closeModal() {
    if (modalHost) {
      modalHost.remove();
      modalHost = null;
    }
  }

  function renderShadowContent(shadow, text, theme) {
    const timestamp   = formatDate();
    const domain      = getDomain();
    const displayText = truncate(text, 500);
    const brandName   = prefs.brandingName || 'TextCard';

    // ── CSS (scoped inside shadow) ────────────────────────────────────────
    const style = document.createElement('style');
    style.textContent = getShadowStyles(theme);
    shadow.appendChild(style);

    // ── Overlay ───────────────────────────────────────────────────────────
    const overlay = document.createElement('div');
    overlay.className = 'tc-overlay';
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal();
    });

    // ── Dialog ────────────────────────────────────────────────────────────
    const dialog = document.createElement('div');
    dialog.className   = 'tc-dialog';
    dialog.setAttribute('role', 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-label', 'Postcard Preview');

    // ── Header ────────────────────────────────────────────────────────────
    const header = document.createElement('div');
    header.className = 'tc-header';
    header.innerHTML = `
      <div class="tc-header-left">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <rect x="2" y="3" width="20" height="18" rx="3" stroke="currentColor" stroke-width="2"/>
          <line x1="7" y1="9" x2="17" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <line x1="7" y1="13" x2="14" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <span class="tc-header-title">TextCard</span>
      </div>
      <button class="tc-close-btn" id="tc-close" aria-label="Close" title="Close (Esc)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        </svg>
      </button>
    `;

    // ── Theme Picker ──────────────────────────────────────────────────────
    const themePicker = document.createElement('div');
    themePicker.className = 'tc-theme-picker';
    const themeColors = {
      dark:    '#302b63',
      light:   '#e8ecf0',
      sunset:  '#8b1a4a',
      ocean:   '#0d3b6e',
      forest:  '#1b4332',
    };
    Object.entries(THEMES).forEach(([key, t]) => {
      const dot = document.createElement('button');
      dot.className = `tc-theme-dot${prefs.theme === key ? ' active' : ''}`;
      dot.id        = `tc-theme-${key}`;
      dot.title     = t.label;
      dot.setAttribute('aria-label', `Theme: ${t.label}`);
      dot.style.background = themeColors[key] || t.accent;
      dot.addEventListener('click', () => {
        prefs.theme = key;
        try { chrome.storage.sync.set({ theme: key }); } catch {}
        closeModal();
        openModal(text); // Reopen with new theme
      });
      themePicker.appendChild(dot);
    });

    // ── Postcard ──────────────────────────────────────────────────────────
    const card = createPostcardDOM(displayText, domain, timestamp, brandName, theme);
    card.id = 'tc-postcard';

    // ── Toolbar ───────────────────────────────────────────────────────────
    const toolbar = document.createElement('div');
    toolbar.className = 'tc-toolbar';
    toolbar.innerHTML = `
      <button class="tc-btn tc-btn-primary" id="tc-download">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <path d="M12 15l-4-4h3V4h2v7h3l-4 4z" fill="currentColor"/>
          <path d="M5 18h14v2H5z" fill="currentColor"/>
        </svg>
        Download PNG
      </button>
      <button class="tc-btn tc-btn-secondary" id="tc-copy">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <rect x="9" y="9" width="13" height="13" rx="2" stroke="currentColor" stroke-width="2"/>
          <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" stroke="currentColor" stroke-width="2"/>
        </svg>
        Copy to Clipboard
      </button>
    `;

    // ── Status bar ────────────────────────────────────────────────────────
    const status = document.createElement('div');
    status.className = 'tc-status';
    status.id        = 'tc-status';

    // ── Assemble ──────────────────────────────────────────────────────────
    dialog.appendChild(header);
    dialog.appendChild(themePicker);
    dialog.appendChild(card);
    dialog.appendChild(toolbar);
    dialog.appendChild(status);
    overlay.appendChild(dialog);
    shadow.appendChild(overlay);

    // ── Wire up buttons ───────────────────────────────────────────────────
    shadow.getElementById('tc-close').addEventListener('click', closeModal);

    shadow.getElementById('tc-download').addEventListener('click', () => {
      if (isGenerating) return;
      handleAction('download', card, brandName, shadow);
    });

    shadow.getElementById('tc-copy').addEventListener('click', () => {
      if (isGenerating) return;
      handleAction('copy', card, brandName, shadow);
    });

    // Animate in
    requestAnimationFrame(() => {
      overlay.classList.add('tc-overlay--visible');
      dialog.classList.add('tc-dialog--visible');
    });
  }

  // ── Postcard DOM Builder ──────────────────────────────────────────────────
  function createPostcardDOM(text, domain, timestamp, brandName, theme) {
    const card = document.createElement('div');
    card.className = 'tc-card-wrapper';

    card.innerHTML = `
      <div class="tc-postcard" id="tc-postcard-inner">
        <div class="tc-postcard-bg"></div>
        <div class="tc-postcard-content">
          <div class="tc-postcard-header">
            <div class="tc-domain">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" style="flex-shrink:0">
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
                <path d="M2 12h20M12 2c-2.5 3-4 6.5-4 10s1.5 7 4 10M12 2c2.5 3 4 6.5 4 10s-1.5 7-4 10" stroke="currentColor" stroke-width="1.5"/>
              </svg>
              <span>${escapeHTML(domain)}</span>
            </div>
            <div class="tc-divider-line"></div>
          </div>

          <div class="tc-postcard-body">
            <div class="tc-quote-mark">"</div>
            <div class="tc-text">${escapeHTML(text)}</div>
          </div>

          <div class="tc-postcard-footer">
            <div class="tc-timestamp">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" style="flex-shrink:0">
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
                <path d="M12 6v6l4 2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              </svg>
              <span>${escapeHTML(timestamp)}</span>
            </div>
            <div class="tc-branding">
              <span>${escapeHTML(brandName)}</span>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" style="flex-shrink:0">
                <rect x="2" y="3" width="20" height="18" rx="3" stroke="currentColor" stroke-width="2"/>
                <line x1="7" y1="9" x2="17" y2="9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                <line x1="7" y1="13" x2="14" y2="13" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
              </svg>
            </div>
          </div>
        </div>

        <div class="tc-postcard-stamp">
          <div class="tc-stamp-inner">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="3" width="20" height="18" rx="3" stroke="currentColor" stroke-width="2"/>
              <line x1="7" y1="9" x2="17" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              <line x1="7" y1="13" x2="14" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
        </div>
      </div>
    `;

    // Apply theme variables via inline CSS on the postcard inner
    const inner = card.querySelector('#tc-postcard-inner');
    inner.style.cssText = `
      --tc-bg:     ${THEMES[prefs.theme]?.background || THEMES.dark.background};
      --tc-card:   ${THEMES[prefs.theme]?.card       || THEMES.dark.card};
      --tc-border: ${THEMES[prefs.theme]?.border      || THEMES.dark.border};
      --tc-text:   ${THEMES[prefs.theme]?.text        || THEMES.dark.text};
      --tc-meta:   ${THEMES[prefs.theme]?.meta        || THEMES.dark.meta};
      --tc-accent: ${THEMES[prefs.theme]?.accent      || THEMES.dark.accent};
      --tc-shadow: ${THEMES[prefs.theme]?.shadow      || THEMES.dark.shadow};
    `;

    return card;
  }

  // ── Generate & Act ────────────────────────────────────────────────────────
  async function handleAction(action, cardWrapper, brandName, shadow) {
    const statusEl  = shadow.getElementById('tc-status');
    const dlBtn     = shadow.getElementById('tc-download');
    const cpBtn     = shadow.getElementById('tc-copy');
    const targetEl  = cardWrapper.querySelector('#tc-postcard-inner');

    isGenerating = true;
    dlBtn.disabled = cpBtn.disabled = true;
    setStatus(statusEl, 'loading', 'Generating postcard…');

    try {
      // Give the browser a frame to repaint the button states
      await nextFrame();
      await nextFrame();

      const canvas = await renderToCanvas(targetEl);

      if (action === 'download') {
        downloadCanvas(canvas, brandName);
        setStatus(statusEl, 'success', '✓ Download started!');
      } else {
        await copyCanvasToClipboard(canvas);
        setStatus(statusEl, 'success', '✓ Copied to clipboard!');
      }
    } catch (err) {
      console.error('[TextCard] Generation error:', err);
      setStatus(statusEl, 'error', `✗ Error: ${err.message || 'Failed to generate postcard'}`);
    } finally {
      isGenerating = false;
      dlBtn.disabled = cpBtn.disabled = false;
      setTimeout(() => clearStatus(statusEl), 4000);
    }
  }

  async function renderToCanvas(element) {
    if (typeof html2canvas !== 'function') {
      throw new Error('html2canvas not loaded');
    }

    return await html2canvas(element, {
      backgroundColor: null,
      scale:           2,         // 2× for crisp PNG
      useCORS:         true,
      allowTaint:      false,
      logging:         false,
      removeContainer: true,
      foreignObjectRendering: false,
      onclone: (clonedDoc, clonedEl) => {
        // Ensure the clone has no hidden overflow
        clonedEl.style.overflow  = 'visible';
        clonedEl.style.maxHeight = 'none';
      },
    });
  }

  function downloadCanvas(canvas, brandName) {
    const link = document.createElement('a');
    link.download = `${sanitizeFilename(brandName)}-postcard-${Date.now()}.png`;
    link.href     = canvas.toDataURL('image/png', 1.0);
    link.click();
  }

  async function copyCanvasToClipboard(canvas) {
    return new Promise((resolve, reject) => {
      canvas.toBlob(async (blob) => {
        if (!blob) { reject(new Error('Canvas to blob failed')); return; }
        try {
          await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': blob }),
          ]);
          resolve();
        } catch (err) {
          reject(err);
        }
      }, 'image/png', 1.0);
    });
  }

  // ── Utilities ─────────────────────────────────────────────────────────────
  function nextFrame() {
    return new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  }

  function sanitizeFilename(name) {
    return name.replace(/[^a-zA-Z0-9_-]/g, '-').toLowerCase().slice(0, 40) || 'textcard';
  }

  function setStatus(el, type, msg) {
    if (!el) return;
    el.className = `tc-status tc-status--${type}`;
    el.textContent = msg;
  }

  function clearStatus(el) {
    if (!el) return;
    el.className = 'tc-status';
    el.textContent = '';
  }

  // ── Shadow DOM Styles ─────────────────────────────────────────────────────
  function getShadowStyles(theme) {
    return `
      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

      /* Google Font embedded as base64 is too large; use system fallbacks */
      :host {
        font-family: 'Segoe UI', system-ui, -apple-system, BlinkMacSystemFont,
                     'Helvetica Neue', Arial, sans-serif;
      }

      /* ── Overlay ── */
      .tc-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.65);
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        opacity: 0;
        transition: opacity 0.25s ease;
        overflow-y: auto;
      }
      .tc-overlay--visible { opacity: 1; }

      /* ── Dialog ── */
      .tc-dialog {
        background: #13111e;
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 20px;
        padding: 24px;
        width: 100%;
        max-width: 620px;
        box-shadow: 0 32px 80px rgba(0,0,0,0.7);
        display: flex;
        flex-direction: column;
        gap: 16px;
        transform: translateY(20px) scale(0.97);
        opacity: 0;
        transition: transform 0.28s cubic-bezier(0.34,1.56,0.64,1),
                    opacity 0.25s ease;
        position: relative;
      }
      .tc-dialog--visible {
        transform: translateY(0) scale(1);
        opacity: 1;
      }

      /* ── Header ── */
      .tc-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .tc-header-left {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #a78bfa;
        font-size: 15px;
        font-weight: 700;
        letter-spacing: 0.02em;
      }
      .tc-header-title {
        background: linear-gradient(90deg, #a78bfa, #60a5fa);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }
      .tc-close-btn {
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.6);
        width: 34px; height: 34px;
        border-radius: 50%;
        cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: background 0.15s, color 0.15s;
      }
      .tc-close-btn:hover {
        background: rgba(255,100,100,0.15);
        color: #f87171;
      }

      /* ── Theme Picker ── */
      .tc-theme-picker {
        display: flex;
        gap: 8px;
        align-items: center;
        padding: 2px 0;
      }
      .tc-theme-dot {
        width: 22px; height: 22px;
        border-radius: 50%;
        border: 2px solid transparent;
        cursor: pointer;
        transition: transform 0.15s, border-color 0.15s;
        outline: none;
      }
      .tc-theme-dot:hover { transform: scale(1.2); }
      .tc-theme-dot.active {
        border-color: #fff;
        transform: scale(1.15);
        box-shadow: 0 0 0 3px rgba(167,139,250,0.4);
      }

      /* ── Card Wrapper ── */
      .tc-card-wrapper {
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 30px rgba(0,0,0,0.4);
      }

      /* ── Postcard ── */
      .tc-postcard {
        position: relative;
        min-height: 260px;
        overflow: hidden;
        display: flex;
        isolation: isolate;
        background: var(--tc-bg, linear-gradient(135deg, #0f0c29, #302b63, #24243e));
      }
      .tc-postcard-bg {
        position: absolute;
        inset: 0;
        background: inherit;
        z-index: 0;
      }
      /* Subtle noise overlay */
      .tc-postcard-bg::after {
        content: '';
        position: absolute;
        inset: 0;
        background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
        opacity: 0.4;
        pointer-events: none;
      }

      .tc-postcard-content {
        position: relative;
        z-index: 1;
        display: flex;
        flex-direction: column;
        flex: 1;
        padding: 28px 32px 24px;
        gap: 0;
      }

      /* Header row */
      .tc-postcard-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
      }
      .tc-domain {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 11.5px;
        font-weight: 600;
        color: var(--tc-meta, rgba(200,200,255,0.55));
        letter-spacing: 0.06em;
        text-transform: lowercase;
        white-space: nowrap;
        flex-shrink: 0;
      }
      .tc-divider-line {
        flex: 1;
        height: 1px;
        background: var(--tc-border, rgba(255,255,255,0.12));
      }

      /* Body */
      .tc-postcard-body {
        flex: 1;
        position: relative;
        padding: 0 0 20px;
      }
      .tc-quote-mark {
        position: absolute;
        top: -24px;
        left: -8px;
        font-size: 80px;
        line-height: 1;
        color: var(--tc-accent, #7c6ff7);
        opacity: 0.18;
        font-family: Georgia, serif;
        pointer-events: none;
        user-select: none;
      }
      .tc-text {
        font-size: 17px;
        line-height: 1.72;
        color: var(--tc-text, #f0f0f0);
        word-break: break-word;
        white-space: pre-wrap;
        max-height: 320px;
        overflow: hidden;
        font-weight: 400;
        letter-spacing: 0.01em;
        position: relative;
        z-index: 1;
      }

      /* Footer row */
      .tc-postcard-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding-top: 8px;
        border-top: 1px solid var(--tc-border, rgba(255,255,255,0.09));
        margin-top: auto;
      }
      .tc-timestamp, .tc-branding {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 11px;
        color: var(--tc-meta, rgba(200,200,255,0.55));
        letter-spacing: 0.04em;
        font-weight: 500;
      }

      /* Stamp decoration */
      .tc-postcard-stamp {
        position: absolute;
        top: 18px;
        right: 22px;
        z-index: 2;
        opacity: 0.35;
      }
      .tc-stamp-inner {
        width: 42px; height: 42px;
        border: 2px dashed currentColor;
        border-radius: 6px;
        display: flex; align-items: center; justify-content: center;
        color: var(--tc-accent, #7c6ff7);
      }

      /* ── Toolbar ── */
      .tc-toolbar {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }
      .tc-btn {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 10px 20px;
        border-radius: 10px;
        font-size: 13.5px;
        font-weight: 600;
        cursor: pointer;
        border: none;
        outline: none;
        transition: transform 0.15s, box-shadow 0.15s, opacity 0.15s;
        font-family: inherit;
        letter-spacing: 0.01em;
        white-space: nowrap;
      }
      .tc-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none !important;
      }
      .tc-btn:not(:disabled):hover { transform: translateY(-1px); }
      .tc-btn:not(:disabled):active { transform: translateY(0); }

      .tc-btn-primary {
        background: linear-gradient(135deg, #7c6ff7, #a78bfa);
        color: #fff;
        box-shadow: 0 4px 16px rgba(124,111,247,0.4);
      }
      .tc-btn-primary:not(:disabled):hover {
        box-shadow: 0 6px 22px rgba(124,111,247,0.55);
      }
      .tc-btn-secondary {
        background: rgba(255,255,255,0.07);
        border: 1px solid rgba(255,255,255,0.12);
        color: rgba(255,255,255,0.85);
      }
      .tc-btn-secondary:not(:disabled):hover {
        background: rgba(255,255,255,0.12);
      }

      /* ── Status ── */
      .tc-status {
        min-height: 20px;
        font-size: 12.5px;
        font-weight: 500;
        border-radius: 8px;
        padding: 0;
        transition: all 0.2s;
        letter-spacing: 0.02em;
      }
      .tc-status--loading { color: #a78bfa; }
      .tc-status--success { color: #4ade80; }
      .tc-status--error   { color: #f87171; }
    `;
  }

})();
