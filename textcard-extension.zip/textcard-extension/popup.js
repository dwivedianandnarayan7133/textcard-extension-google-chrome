/**
 * popup.js – TextCard Popup Settings
 * Loads and saves user preferences (branding name, default theme)
 * using chrome.storage.sync.
 */

'use strict';

const DEFAULT_PREFS = {
  theme:        'dark',
  brandingName: 'TextCard',
};

// ── DOM refs ─────────────────────────────────────────────────────────────────
const brandingInput  = document.getElementById('branding-name');
const themeSelect    = document.getElementById('default-theme');
const saveBtn        = document.getElementById('save-btn');
const resetBtn       = document.getElementById('reset-btn');
const saveStatus     = document.getElementById('save-status');

// ── Load preferences on open ──────────────────────────────────────────────────
chrome.storage.sync.get(DEFAULT_PREFS, (result) => {
  brandingInput.value = result.brandingName || DEFAULT_PREFS.brandingName;
  themeSelect.value   = result.theme        || DEFAULT_PREFS.theme;
});

// ── Save ──────────────────────────────────────────────────────────────────────
saveBtn.addEventListener('click', () => {
  const brandingName = brandingInput.value.trim() || DEFAULT_PREFS.brandingName;
  const theme        = themeSelect.value          || DEFAULT_PREFS.theme;

  saveBtn.disabled = true;

  chrome.storage.sync.set({ brandingName, theme }, () => {
    saveBtn.disabled = false;
    if (chrome.runtime.lastError) {
      showStatus('error', `✗ ${chrome.runtime.lastError.message}`);
    } else {
      showStatus('success', '✓ Settings saved!');
    }
  });
});

// ── Reset ─────────────────────────────────────────────────────────────────────
resetBtn.addEventListener('click', () => {
  chrome.storage.sync.set(DEFAULT_PREFS, () => {
    brandingInput.value = DEFAULT_PREFS.brandingName;
    themeSelect.value   = DEFAULT_PREFS.theme;
    showStatus('success', '✓ Reset to defaults');
  });
});

// ── Helpers ───────────────────────────────────────────────────────────────────
let statusTimer = null;

function showStatus(type, msg) {
  saveStatus.textContent = msg;
  saveStatus.className   = `save-status ${type}`;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => {
    saveStatus.textContent = '';
    saveStatus.className   = 'save-status';
  }, 3000);
}
