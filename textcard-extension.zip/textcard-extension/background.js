/**
 * background.js – TextCard Service Worker
 * Handles context menus, keyboard commands, and message routing.
 */

const CONTEXT_MENU_ID = 'textcard-generate';

// ── Context Menu Setup ────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id:       CONTEXT_MENU_ID,
    title:    '🃏 Generate Postcard',
    contexts: ['selection'],
  });
});

// ── Context Menu Click ────────────────────────────────────────────────────────
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID) return;
  if (!info.selectionText?.trim()) return;

  chrome.tabs.sendMessage(tab.id, {
    action: 'OPEN_POSTCARD_FROM_CONTEXT',
    text:   info.selectionText.trim(),
  }).catch(() => {
    // Content script not ready – inject it on-the-fly
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files:  ['lib/html2canvas.min.js', 'content.js'],
    }).then(() => {
      chrome.tabs.sendMessage(tab.id, {
        action: 'OPEN_POSTCARD_FROM_CONTEXT',
        text:   info.selectionText.trim(),
      });
    });
  });
});

// ── Keyboard Shortcut ─────────────────────────────────────────────────────────
chrome.commands.onCommand.addListener((command, tab) => {
  if (command !== 'generate-postcard') return;
  chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_FROM_SHORTCUT' }).catch(() => {});
});

// ── Message Relay ─────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'GET_TAB_URL') {
    sendResponse({ url: sender.tab?.url ?? '' });
    return true;
  }
});
